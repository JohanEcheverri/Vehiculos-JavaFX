package co.edu.uniquindio.poo.model;

public class Camioneta extends Vehiculo {
    private double capacidadCarga;

    public Camioneta(double capacidadCarga, String matricula, String marca, String modelo, int añoFabricacion) {
        super(matricula, marca, modelo, añoFabricacion);
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void calcularCostoReserva() {//incluye % extra por tonelada
    }

    public double getCapacidadCarga() {
        return capacidadCarga;
    }

    public void setCapacidadCarga(double capacidadCarga) {
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public String toString() {
        return "Camioneta [capacidadCarga=" + capacidadCarga + "]" + super.toString();
    }
    


    
}
